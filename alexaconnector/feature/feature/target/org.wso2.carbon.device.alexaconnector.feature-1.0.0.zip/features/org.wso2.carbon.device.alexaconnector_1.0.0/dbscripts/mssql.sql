
-- -----------------------------------------------------
-- Table `alexaconnector_DEVICE`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS alexaconnector_DEVICE (
  alexaconnector_DEVICE_ID VARCHAR(45) NOT NULL ,
  DEVICE_NAME VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (alexaconnector_DEVICE_ID) );

